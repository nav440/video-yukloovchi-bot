# Video Yuklovchi Bot

Telegram bot — YouTube, Instagram, TikTok va Twitter (X) dan video yuklab beradi.

## Fayllar
- `bot.py` — bot kodi
- `requirements.txt` — kerakli kutubxonalar
- `Procfile` — Railway/Heroku uchun ishga tushirish buyrug'i
- `nixpacks.toml` — build vaqtida ffmpeg o'rnatish uchun

## Mahalliy ishga tushirish

1. Python 3.11+ o'rnating
2. Kutubxonalarni o'rnating:
   ```
   pip install -r requirements.txt
   ```
3. `ffmpeg` o'rnatilganligiga ishonch hosil qiling (mahalliy kompyuterda):
   - Ubuntu/Debian: `sudo apt install ffmpeg`
   - Mac: `brew install ffmpeg`
   - Windows: https://ffmpeg.org/download.html dan yuklab, PATH ga qo'shing
4. `BOT_TOKEN` muhit o'zgaruvchisini o'rnating:
   ```
   export BOT_TOKEN="123456:ABC-DEF..."
   ```
5. Botni ishga tushiring:
   ```
   python bot.py
   ```

## Railway'ga deploy qilish

1. Bu papkani GitHub repo qiling va Railway'ga ulang (yoki Railway CLI orqali yuklang)
2. Railway loyihasida **Variables** bo'limiga kirib `BOT_TOKEN` ni qo'shing
3. Railway `nixpacks.toml` faylini avtomatik topadi va `ffmpeg` ni o'rnatadi
4. Deploy tugagach, loglarda "Bot polling boshlandi..." degan xabarni ko'rishingiz kerak

## Muhim eslatmalar

- Telegram bot API orqali 50 MB dan katta faylni yuborib bo'lmaydi — kod buni avtomatik tekshiradi
- Instagram va TikTok ba'zan login/cookie talab qilishi mumkin (xususiy postlar uchun) — bu holda ochiq (public) linklardan foydalaning
- yt-dlp doim yangilanib turadi (platformalar formatini o'zgartirganda), shuning uchun vaqti-vaqti bilan:
  ```
  pip install -U yt-dlp
  ```
  qilib turish tavsiya etiladi
