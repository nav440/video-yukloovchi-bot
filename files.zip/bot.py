import os
import logging
import tempfile
import shutil

from telegram import Update
from telegram.constants import ChatAction
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters

import yt_dlp

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

BOT_TOKEN = os.environ.get("BOT_TOKEN")
MAX_FILE_SIZE_MB = 49  # Telegram bot API limit is 50MB for sendVideo

SUPPORTED_DOMAINS = (
    "youtube.com", "youtu.be",
    "instagram.com",
    "tiktok.com",
    "twitter.com", "x.com",
)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Salom! 👋\n\n"
        "Menga YouTube, Instagram, TikTok yoki Twitter (X) videosining "
        "havolasini yuboring — men uni siz uchun yuklab beraman.\n\n"
        "Shunchaki linkni yuboring."
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Qo'llab-quvvatlanadigan platformalar:\n"
        "• YouTube\n• Instagram\n• TikTok\n• Twitter / X\n\n"
        "Video havolasini yuboring, men yuklab beraman."
    )


def _looks_like_supported_link(text: str) -> bool:
    text = text.lower()
    return text.startswith("http") and any(domain in text for domain in SUPPORTED_DOMAINS)


def _download_video(url: str, out_dir: str) -> str:
    """Downloads the video with yt-dlp and returns the local file path."""
    out_template = os.path.join(out_dir, "%(id)s.%(ext)s")

    ydl_opts = {
        "outtmpl": out_template,
        "format": "mp4/bestvideo[ext=mp4]+bestaudio[ext=m4a]/best",
        "merge_output_format": "mp4",
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        # Keeps file size reasonable where the site allows format selection
        "format_sort": ["filesize~30M"],
    }

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        filename = ydl.prepare_filename(info)
        # merge_output_format may change extension to .mp4 after postprocessing
        if not os.path.exists(filename):
            base, _ = os.path.splitext(filename)
            candidate = base + ".mp4"
            if os.path.exists(candidate):
                filename = candidate
        return filename


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or "").strip()

    if not _looks_like_supported_link(text):
        await update.message.reply_text(
            "Iltimos, YouTube, Instagram, TikTok yoki Twitter (X) "
            "videosining to'g'ri havolasini yuboring."
        )
        return

    status_msg = await update.message.reply_text("⏳ Video yuklanmoqda, kuting...")
    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action=ChatAction.UPLOAD_VIDEO)

    tmp_dir = tempfile.mkdtemp(prefix="ytdlp_")
    try:
        file_path = _download_video(text, tmp_dir)

        size_mb = os.path.getsize(file_path) / (1024 * 1024)
        if size_mb > MAX_FILE_SIZE_MB:
            await status_msg.edit_text(
                f"⚠️ Video hajmi juda katta ({size_mb:.1f} MB). "
                f"Telegram bot orqali {MAX_FILE_SIZE_MB} MB dan katta faylni yuborib bo'lmaydi."
            )
            return

        await status_msg.edit_text("📤 Yuborilmoqda...")
        with open(file_path, "rb") as video_file:
            await update.message.reply_video(video=video_file, supports_streaming=True)
        await status_msg.delete()

    except yt_dlp.utils.DownloadError as e:
        logger.warning(f"Download error for {text}: {e}")
        await status_msg.edit_text(
            "❌ Videoni yuklab bo'lmadi. Havola noto'g'ri, video xususiy (private) "
            "yoki platforma tomonidan cheklangan bo'lishi mumkin."
        )
    except Exception as e:
        logger.exception(f"Unexpected error handling {text}")
        await status_msg.edit_text("❌ Kutilmagan xatolik yuz berdi. Birozdan so'ng qayta urinib ko'ring.")
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def main():
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN environment variable is not set")

    application = Application.builder().token(BOT_TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    logger.info("Bot polling boshlandi...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
